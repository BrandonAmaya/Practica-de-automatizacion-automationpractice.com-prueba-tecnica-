import net.serenitybdd.core.pages.WebElementResolver
import net.serenitybdd.core.pages.WebElementState
import net.serenitybdd.junit.runners.SerenityRunner
import net.serenitybdd.screenplay.Actor
import net.serenitybdd.screenplay.GivenWhenThen.seeThat
import net.serenitybdd.screenplay.abilities.BrowseTheWeb
import net.serenitybdd.screenplay.actions.Click
import net.serenitybdd.screenplay.actions.Enter
import net.serenitybdd.screenplay.actions.Open
import net.serenitybdd.screenplay.actions.SelectFromOptions
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers
import net.serenitybdd.screenplay.questions.Text
import net.serenitybdd.screenplay.questions.WebElementQuestion
import net.serenitybdd.screenplay.targets.Target
import net.serenitybdd.screenplay.waits.WaitUntil
import net.thucydides.core.annotations.Managed
import org.junit.Test
import org.junit.runner.RunWith
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.chrome.ChromeDriver
import java.lang.System.setProperty
import java.sql.DriverManager.println

@RunWith(SerenityRunner::class)
class ExampleTest {
    @Managed
    var webDriver: WebDriver? = null

    @Test
    fun navigateToContactPage(){
        //C:\Users\brand\Downloads\chromedriver.exe
        //System.setProperty("webdriver.chrome.driver", "C:/Users/brand/Downloads/chromedriver.exe")

        val subjectHeading =Target.the("subject Heading")
            .located(By.cssSelector("select#id_contact"))

        val emailAddress =Target.the("Email address")
            .located(By.cssSelector("input#email"))

        val orderReference =Target.the("Order reference")
            .located(By.cssSelector("input#id_order"))

        val menssage =Target.the("Menssagge")
            .located(By.cssSelector("textarea#message"))

        val send =Target.the("Send")
            .located(By.cssSelector("button#submitMessage"))

        val brandon = Actor.named("Brandon")
        brandon.can(BrowseTheWeb.with(webDriver))

        brandon.attemptsTo(
            Open.url("http://automationpractice.com/index.php?controller=contact"),
            Enter.theValue("jose@gmail.com").into(emailAddress),
            Enter.theValue("11111117").into(orderReference),
            Enter.theValue(" lo estoy logrando :)").into(menssage),
            SelectFromOptions.byVisibleText("Customer service").from(subjectHeading),
            Click.on(send)
        )
    }
    @Test
    fun `invalid email contact page`(){
        val brandon=Actor.named("Brandon")

        val send =Target.the("Send")
            .located(By.cssSelector("button#submitMessage"))

        val errorMensagge =Target.the("error Mensaje")
            .located(By.cssSelector("div.alert-danger"))

        brandon.can(BrowseTheWeb.with(webDriver))

        brandon.attemptsTo(
            Open.url("http://automationpractice.com/index.php?controller=contact"),
            Click.on(send)
            )

       // brandon.should(//comprobar que el mensaje de error esta
       //     seeThat(WebElementQuestion.the(errorMensagge),
       //         WebElementStateMatchers.isVisible())
       // )
        brandon.attemptsTo(
            WaitUntil.the(errorMensagge,WebElementStateMatchers.isVisible())
                .forNoMoreThan(12)
                .seconds()
        )


        val error1=errorMensagge.resolveFor(brandon).text
        val error2=Text.of(errorMensagge).asAString().answeredBy(brandon)

        println("el valor de error1 es $error1")


        brandon.attemptsTo(
            WaitUntil.the(errorMensagge,WebElementStateMatchers.isVisible())
                .forNoMoreThan(12)
                .seconds()
        )
    }
    @Test
    fun `select random dress`(){

        val brandon=Actor.named("Brandon")
        brandon.can(BrowseTheWeb.with(webDriver))

        brandon.attemptsTo(
            Open.url("http://automationpractice.com/index.php"),
            //Click.on(send)
        )

        val products =Target.the("Products")
            .locatedBy("ul#homefeatured li div.product-container")

        val productInfo =Target.the("Product info")
            .located(By.cssSelector("div.box-info-product"))

        val product = products.resolveFor(brandon).click()
        println("el producto seleccionado es: ${product}")

        brandon.should(
            seeThat(WebElementQuestion.the(productInfo),WebElementStateMatchers.isVisible())
        )

    }
    @Test
    fun `invalid email`(){
        val brandon=Actor.named("Brandon")

        val signIn =Target.the("Sign In")
            .located(By.cssSelector("button#SubmitLogin"))

        val emailAddress =Target.the("Email Address")
            .located(By.cssSelector("input#email"))

        val errorMensagge =Target.the("error Mensaje")
            .located(By.cssSelector("div.alert-danger"))
        val password =Target.the("Password")
            .located(By.cssSelector("input#passwd"))

        brandon.can(BrowseTheWeb.with(webDriver))

        brandon.attemptsTo(
            Open.url("http://automationpractice.com/index.php?controller=authentication&back=my-account"),
            Enter.theValue("jose@gmail.com").into(emailAddress),
            Enter.theValue("12345678").into(password),
            Click.on(signIn),
        )

        brandon.should(//comprobar que el mensaje de error esta
            seeThat(WebElementQuestion.the(errorMensagge),
                WebElementStateMatchers.isVisible())
        )

        val error1=errorMensagge.resolveFor(brandon).text

        brandon.attemptsTo(
            WaitUntil.the(errorMensagge,WebElementStateMatchers.isVisible())
                .forNoMoreThan(12)
                .seconds()
        )
    }
    @Test
    fun `Sign in`(){

        val brandon=Actor.named("Brandon")
        brandon.can(BrowseTheWeb.with(webDriver))


        val emailAddress =Target.the("Email Address")
            .located(By.cssSelector("input#email"))

        val password =Target.the("Password")
            .located(By.cssSelector("input#passwd"))

        val signIn =Target.the("Sign In")
            .located(By.cssSelector("button#SubmitLogin"))

        val pageHeading =Target.the("Page Heading")
            .located(By.cssSelector("h1.page-heading"))

        brandon.attemptsTo(
            Open.url("http://automationpractice.com/index.php?controller=authentication&back=my-account"),
            Enter.theValue("jose1@gmail.com").into(emailAddress),
            Enter.theValue("12345678").into(password),
            Click.on(signIn),
            WaitUntil.the(pageHeading,WebElementStateMatchers.isVisible())
                .forNoMoreThan(12)
                .seconds()
        )
    }
    @Test
    fun `select  dress`(){

        val brandon=Actor.named("Brandon")
        brandon.can(BrowseTheWeb.with(webDriver))

        brandon.attemptsTo(
            Open.url("http://automationpractice.com/index.php"),

            )

        val products =Target.the("Products")
            .located(By.cssSelector("ul#homefeatured li div.product-container"))

        val productInfo =Target.the("Product info")
            .located(By.cssSelector("div.box-info-product"))

        val product = products.resolveFor(brandon).click()
        println("el producto seleccionado es: ${product}")

        brandon.attemptsTo(Click.on(products))

        brandon.should(
            seeThat(WebElementQuestion.the(productInfo),WebElementStateMatchers.isVisible())
        )

    }
}